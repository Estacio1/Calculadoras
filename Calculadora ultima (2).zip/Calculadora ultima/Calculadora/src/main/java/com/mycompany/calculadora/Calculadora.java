package com.mycompany.calculadora;

import java.util.Scanner;
import java.lang.Math;
import java.util.Arrays;

public class Calculadora {
    public static void main(String[] args) throws Exception {
        String operacion;
        char caracter;
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingresar cálculo");
        operacion = leer.next();
        int tamaño = operacion.length();
        int prioridad[][] = new int[tamaño][2];
        int pos_op = 0;
        int error = 0;
        double resultado[] = new double[tamaño];
        for (int i = 0; i < tamaño; i++) {
            caracter = operacion.charAt(i);
            switch (caracter) {

                case '+': {
                    prioridad[pos_op][0] = 3;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }

                case '-': {
                    prioridad[pos_op][0] = 3;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }

                case '*': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case '/': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case 'i': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case 'r': {
                    prioridad[pos_op][0] = 1;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case '^': {
                    prioridad[pos_op][0] = 1;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case 's': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case 'c': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
                case 't': {
                    prioridad[pos_op][0] = 2;
                    prioridad[pos_op][1] = i;
                    pos_op++;
                    break;
                }
            }
        }
         try
         {
        int valor = 0;
        int op_end[] = new int[pos_op];
        Arrays.fill(op_end, 0);
        int ulti_op = 0;
        for (int i = 0; i < (pos_op); i++) { // Prioridad 1/////////////////////////////////////////////////
            int posicion = prioridad[i][1];
            int iniciox, finalx, inicioy, finaly;
            double x, y;
            if (i == 0) {
                iniciox = 0;
            } else {
                iniciox = prioridad[i - 1][1] + 1;
            }
            if (i == (pos_op) - 1) {
                finaly = tamaño - 1;
            } else {
                finaly = posicion + 1;
            }
            finalx = posicion - 1;
            inicioy = posicion + 1;

            if (prioridad[i][0] == 1) {
                if (operacion.charAt(posicion) == '^') {

                    x = Integer.parseInt(operacion.substring(iniciox, finalx + 1));
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = Math.pow(x, y);
                    op_end[i] = 1;
                    ulti_op = i;
                } else {
                    String raiz;
                    if (i == (pos_op) - 1) {
                        finaly = tamaño - 1;
                    } else {
                        finaly = posicion + 1;
                    }
                    raiz = operacion.substring(inicioy, finaly + 1);
                    String[] parts = raiz.split(",");
                    x = Integer.parseInt(parts[0]);
                    y = Integer.parseInt(parts[1]);
                    if (i != 0 && i != (pos_op) - 1) {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = Math.pow(y, 1 / x);
                    ulti_op = i;
                }
            }
        }

        for (int i = 0; i < (pos_op); i++) { // Prioridad 2/////////////////////////////////////////////////
            int posicion = prioridad[i][1];
            int iniciox, finalx, inicioy, finaly;
            double x, y;

            if (i == 0) {
                iniciox = 0;
            } else {
                iniciox = prioridad[i - 1][1] + 1;
            }
            if (i == (pos_op) - 1) {
                finaly = tamaño - 1;
            } else {
                finaly = posicion + 1;
            }
            finalx = posicion - 1;
            inicioy = posicion + 1;

            if (prioridad[i][0] == 2) {
                if (operacion.charAt(posicion) == '*') {

                    x = Integer.parseInt(operacion.substring(iniciox, finalx + 1));
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = x * y;
                    op_end[i] = 1;
                    ulti_op = i;
                }

                else if (operacion.charAt(posicion) == '/') {
                    x = Integer.parseInt(operacion.substring(iniciox, finalx + 1));
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = x / y;
                    op_end[i] = 1;
                    ulti_op = i;
                }

                else if (operacion.charAt(posicion) == 's') {
                   y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = Math.sin(y);
                    op_end[i] = 1;
                    ulti_op = i;
                }
                else if (operacion.charAt(posicion) == 'c') {
                   y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = Math.cos(y);
                    op_end[i] = 1;
                    ulti_op = i;
                }
                else if (operacion.charAt(posicion) == 't') {
                  y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = Math.tan(y);
                    op_end[i] = 1;
                    ulti_op = i;
                }
                else if (operacion.charAt(posicion) == 'i') {
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = (y*19)/100;
                    op_end[i] = 1;
                    ulti_op = i;
                }

            }
        }
        for (int i = 0; i < (pos_op); i++) { // Prioridad 2/////////////////////////////////////////////////
            int posicion = prioridad[i][1];
            int iniciox, finalx, inicioy, finaly;
            double x, y;

            if (i == 0) {
                iniciox = 0;
            } else {
                iniciox = prioridad[i - 1][1] + 1;
            }
            if (i == (pos_op) - 1) {
                finaly = tamaño - 1;
            } else {
                finaly = posicion + 1;
            }
            finalx = posicion - 1;
            inicioy = posicion + 1;
            if (prioridad[i][0] == 3) {
                if (operacion.charAt(posicion) == '+') {

                    x = Integer.parseInt(operacion.substring(iniciox, finalx + 1));
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = x + y;
                    op_end[i] = 1;
                    ulti_op = i;
                }

                else if (operacion.charAt(posicion) == '-') {
                    x = Integer.parseInt(operacion.substring(iniciox, finalx + 1));
                    y = Integer.parseInt(operacion.substring(inicioy, finaly + 1));
                    if (i != 0 ) {
                        if (op_end[i - 1] == 1) {
                            x = resultado[i - 1];
                        }
                     }
                    if ( i != (pos_op) - 1)
                    {
                        if (op_end[i + 1] == 1) {
                            y = resultado[i + 1];
                        }
                    }
                    resultado[i] = x - y;
                    op_end[i] = 1;
                    ulti_op = i;
                }
            }
        }
        System.out.println("Resultado: " + resultado[ulti_op]);

         }
         catch(Exception e)
         {
         System.out.println("Error de Sintaxis");
         }

    }
}
